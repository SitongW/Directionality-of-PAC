function Y=CFC_entropy_period_cell(C,range1,range2,srate,fil_mode,bin,cross)

num=length(C);
Y=cell(2,num);
n1=size(range1,1);
n2=size(range2,1);
width_wav=7;
for i=1:num
    time1=C{i}(:,1);
    if strcmp(cross,'aa')
        X1=C{i}(:,2);
        X2=C{i}(:,2);
    end
    if strcmp(cross,'ab')
        X1=C{i}(:,2);
        X2=C{i}(:,3);
    end
    if strcmp(cross,'ba')
        X1=C{i}(:,3);
        X2=C{i}(:,2);
    end
    if strcmp(cross,'bb')
        X1=C{i}(:,3);
        X2=C{i}(:,3);
    end
    X1=X1-mean(X1);
    X2=X2-mean(X2);
    len=length(X1);
    for p=1:n1   % theta
        for q=1:n2   % gamma
            if strcmp(fil_mode,'eegfilt')
                x1=eegfilt(X1',srate,range1(p,1),range1(p,2))';
                [x1_ph,x1_ang]=extract_phase_hilbert(x1);
                x2=eegfilt(X2',srate,range2(q,1),range2(q,2))';
                x2_amp=extract_amp_hilbert(x2);
            else if strcmp(fil_mode,'wavelet')
                x1_ang=phasevec((range1(p,1)+range1(p,2))/2,X1,srate,width_wav);
                x2_amp=ampvec((range2(q,1)+range2(q,2))/2,X2,srate,width_wav);
                end
            end
            
            [pdf,ent]=CFC_entropy_period(x1_ang,x2_amp,bin);
            Pdf=mean(pdf);
            Ent=mean(ent);
            
            Y{1,i}(q,p)=Ent;
            Y{2,i}(q,p,:)=Pdf;
        end
    end
end