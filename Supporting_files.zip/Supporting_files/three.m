function [ Nxyz ] = three( x,y,z,binNum )
n=binNum;
Nxyz=zeros(n,n,n);
a=zeros(n+1,1);
N=length(x);

for i=2:(n+1) 
    a(i)=2*pi/n*(i-1);
end

for i=1:N
    k1=0;k2=0;k3=0;
    for k=1:n
        if x(i)>=a(k)&&x(i)<a(k+1)
            k1=k; 
            break            
        end     
    end
    for k=1:n
        if y(i)>=a(k)&&y(i)<a(k+1)
            k2=k; 
            break            
        end     
    end
    for k=1:n
        if z(i)>=a(k)&&z(i)<a(k+1)
            k3=k; 
            break            
        end     
    end
    Nxyz(k1,k2,k3)=Nxyz(k1,k2,k3)+1;
end
