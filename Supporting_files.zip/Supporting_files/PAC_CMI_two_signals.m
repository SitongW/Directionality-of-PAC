function  [D,I12,I21]=PAC_CMI_two_signals(X,Y,range)
[m,n]=size(X);
bin=8;
N=m;
M=0;  
Fs=1000; 
para=zeros(n,12);
F=zeros(n,1);
[f1,spec_perc]=frequency_spectrum(X(:,1),[1,Fs/2],Fs);
a=find(f1>range(1));
a=a(1);
b=find(f1<range(2));
b=b(length(b));
for i=1:n
    x=X(:,i);
    y=Y(:,i);
    [f1,spec_perc]=frequency_spectrum(x,[1,Fs/2],Fs);
    max1=max(spec_perc(a:b));
    j1=find(spec_perc==max1);
    j1=j1(1);
    [f2,spec_perc]=frequency_spectrum(y,[1,Fs/2],Fs);
    max2=max(spec_perc(a:b));
    j2=find(spec_perc==max2);
    j2=j2(1);
    f=max(f1(j1),f2(j2));
    t=floor(Fs/f);
    F(i)=f;
    
    phase_x=extract_phase_hilbert(x);
    phase_x=phase_x(M+1:N-M);
    amplitude_y=extract_amp_hilbert(y);
    phase_y=extract_phase_hilbert(amplitude_y);
    phase_y=phase_y(M+1:N-M);
    [D(i),I12(i),I21(i)]=testIM(phase_x,phase_y,bin,length(phase_x),t);
end