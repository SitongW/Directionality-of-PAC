function [pdf,ent]=CFC_entropy_period(x_ph,y_amp,bin)

diff_x_ph=diff(x_ph);
num=find(diff_x_ph<(-1)*pi); 
n=length(num)-1; 
pdf=zeros(n,bin);
Power=zeros(n,bin);
ent=zeros(n,1);
H_max=log(bin);
figure;
for i=1:n
    n1=num(i)+1;
    n2=num(i+1);
    increment=(x_ph(n2)-x_ph(n1))/bin;
    power=zeros(1,bin);
    x_ph0=x_ph(n1:n2);
    y_amp0=y_amp(n1:n2);
    for j=1:bin
        x_sel=y_amp0( x_ph0>(x_ph(n1)+(j-1)*increment) & x_ph0<(x_ph(n1)+j*increment) );
        if isempty(x_sel)
            power(1,j)=0;
        else
            power(1,j)=mean(x_sel);
        end
    end
    Power(i,:)=power;
    sum0=sum(power);
    if sum0==0
        error('sum0==0')
    end
    pdf(i,:)=power/sum0;
    subplot(10,13,i); plot(pdf(i,:))
    %figure; plot(pdf(i,:))  %%%%%%%%% plot
    H=0;
    for j=1:bin
        if pdf(i,j)~=0
            H=H-pdf(i,j)*log(pdf(i,j));
        end
    end
    ent(i)=(H_max-H)/H_max; 
end
