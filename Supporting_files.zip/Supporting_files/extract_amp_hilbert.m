function amp=extract_amp_hilbert(data)
% get the unwrapped phase,not reduced in [0,2pi]
[m,n]=size(data);
for i=1:n
    x=data(:,i);
    mean_x=mean(x);
    std_x=std(x);
    x=(x-mean_x)/std_x;
    h=hilbert(x);
    amp=abs(h);
end