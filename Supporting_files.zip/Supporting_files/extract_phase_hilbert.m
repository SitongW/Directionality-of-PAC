function [phase,A]=extract_phase_hilbert(data)
% get the unwrapped phase,not reduced in [0,2pi]
[m,n]=size(data);
phase=zeros(m,n);
A=zeros(m,n);
H=zeros(m,n);
for i=1:n
    h=hilbert(data(:,i));
    ang=angle(h);
    %figure;plot(ang);
   % phase0=ang;
   phase0=unwrap(ang);
    %figure;plot(phase0);
    phase(:,i)=phase0;
    A(:,i)=ang;
    H(:,i)=h;
end