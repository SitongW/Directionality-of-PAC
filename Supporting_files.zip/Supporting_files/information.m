function [D12,im31,im13]=information(s,q,st,qt,binN)

%s,q is a 1*N times serias
if nargin < 2, error('Not enough input arguments'),end
if nargin < 5, binN=8,end
%clock %the time of program beginning

N=min(length(s),length(qt));
%his
%Ns=histogram(s,binN);Nq=histogram(q,binN);Nsq=histogram2(s,q,binN);Nst=histogram2(st,s,binN);
%Nqs=histogram2(q,s,binN);Nqt=histogram2(qt,q,binN);
%Nsqt=histogram3(s,qt,q,binN);Nqst=histogram3(q,st,s,binN);
%mine
Ns=one(s,binN);Nq=one(q,binN);
Nsq=two(s,q,binN);
Nst=two(st,s,binN);
Nqs=two(q,s,binN);
Nqt=two(qt,q,binN);
Nsqt=three(s,qt,q,binN);Nqst=three(q,st,s,binN);

Psq=Nsq/N;Pqs=Nqs/N;%�������ϸ���,NΪȫ���������� 
Ps=Ns/N;%�����һ�����еĸ���
Pq=Nq/N;%����ڶ������еĸ���
Pst=Nst/N;
Pqt=Nqt/N;
Psqt=Nsqt/N;
Pqst=Nqst/N;
%����Ϣ�س�ֵ
I12=0;I21=0;
Hs_q=0;Hqt_q=0;Hsqt_q=0;Hq_s=0;Hst_s=0;Hqst_s=0;Hq=0;Hs=0;
for i=1:binN
    if Pq(i)~=0
        Hq=-Pq(i)*log(Pq(i))+Hq;
    end
    if Ps(i)~=0
        Hs=-Ps(i)*log(Ps(i))+Hs;
    end
    for j=1:binN
        if Psq(i,j)~=0 &&Pq(j)~=0
%             Ps_q(i,j)=Psq(i,j)/Pq(j);
           Hs_q=-Psq(i,j)*log(Psq(i,j))+Hs_q;
        end
        if Pqt(i,j)~=0 &&Pq(j)~=0
           Hqt_q=-Pqt(i,j)*log(Pqt(i,j))+Hqt_q; 
        end        
        %calculate sencond one
        if Pqs(i,j)~=0 &&Ps(j)~=0
            Hq_s=-Pqs(i,j)*log(Pqs(i,j))+Hq_s;
        end
        if  Pst(i,j)~=0 &&Ps(j)~=0
            Hst_s=-Pst(i,j)*log(Pst(i,j))+Hst_s;
        end
    end
end
for i=1:binN
    for j=1:binN
        for k=1:binN
            if Psqt(i,j,k)~=0 &&Pq(k)~=0
            %if Psqt(i,j,k)~=0
                Hsqt_q=-Psqt(i,j,k)*log(Psqt(i,j,k))+Hsqt_q;    
            end
            if Pqst(i,j,k)~=0 &&Ps(k)~=0
            %if Pqst(i,j,k)~=0
                Hqst_s=-Pqst(i,j,k)*log(Pqst(i,j,k))+Hqst_s;
            end
        end
    end
end
Hs_q=Hs_q-Hq;Hqt_q=Hqt_q-Hq;Hq_s=Hq_s-Hs;Hst_s=Hst_s-Hs;Hsqt_q=Hsqt_q-Hq;Hqst_s=Hqst_s-Hs;
I12= Hs_q+  Hqt_q - Hsqt_q;   % s �� q��Ӱ��
I21= Hq_s+  Hst_s - Hqst_s;
D12=(I12-I21)/(I12+I21);
%im31=I12/(I12+I21);
%im13=I21/(I12+I21);
im31=I12;
im13=I21;