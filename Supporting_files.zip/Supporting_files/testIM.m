function [Dir,I12,I21]=testIM(C,D,binNum,binWid,delay)

[p1,q1]=size(C);[p2,q2]=size(D);
if q1==1 && p1>1, C=C'; end %
if q2==1 && p2>1, D=D'; end
N=length(C);

M=floor(N/(binWid/2));
Dir=zeros(1,M-1);
I12=zeros(1,M-1);
I21=zeros(1,M-1);
for k=1:M-1% two data get binWid point each time
    c=C((k-1)*(binWid/2)+1:(k+1)*(binWid/2));
    d=D((k-1)*(binWid/2)+1:(k+1)*(binWid/2));
    c1=mod(c(1:binWid-delay),pi+pi);
    d1=mod(d(1:binWid-delay),pi+pi);
    c2=mod(c(1+delay:binWid)-c(1:binWid-delay),pi+pi);
    d2=mod(d(1+delay:binWid)-d(1:binWid-delay),pi+pi);
    
    [Dir(k),I12(k),I21(k)]=information(c1,d1,c2,d2,binNum); %transfer information function;
end