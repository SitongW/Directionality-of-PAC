function [ Nxy,a ] = two( x,y,binNum )
n=binNum;
Nxy=zeros(n,n);
a=zeros(n+1,1);
N=length(x);

for i=2:(n+1) 
    a(i)=2*pi/n*(i-1);
end

for i=1:N
    k1=0;k2=0;
    for k=1:n
        if x(i)>=a(k)&&x(i)<a(k+1)
            k1=k; 
            break            
        end     
    end
    for k=1:n
        if y(i)>=a(k)&&y(i)<a(k+1)
            k2=k; 
            break            
        end     
    end
    Nxy(k1,k2)=Nxy(k1,k2)+1;
end
