function [pdf,ent]=CFC_entropy(x_ph,y_amp,bin)

H_max=log(bin);
a=-pi;
b=pi;
increment=2*pi/bin;

power=zeros(1,bin);
for j=1:bin
    y_sel=y_amp( x_ph>(a+(j-1)*increment) & x_ph<(a+j*increment) );
    if isempty(y_sel)
        power(1,j)=0;
    else
        power(1,j)=mean(y_sel);
    end
end
sum0=sum(power);
if sum0==0
    error('sum0==0')
end
pdf=power/sum0;

H=0;
for j=1:bin
    if pdf(j)~=0
        H=H-pdf(j)*log(pdf(j));
    end
end
ent=(H_max-H)/H_max;

