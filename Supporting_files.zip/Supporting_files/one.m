function [ Nx] = one( x , binNum )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
k=binNum;
a=zeros(k+1,1);
Nx=zeros(k,1);
N=length(x);
for i=2:(k+1) 
    a(i)=2*pi/k*(i-1);
end

for i=1:N
    for j=1:k
        if x(i)>=a(j)&&x(i)<a(j+1)
            Nx(j)=Nx(j)+1; 
            break
        end
    end
end


